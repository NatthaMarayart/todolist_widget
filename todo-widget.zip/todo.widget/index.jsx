// To-do widget for Übersicht (macOS)
// วางโฟลเดอร์ todo.widget ทั้งโฟลเดอร์ใน ~/Library/Application Support/Übersicht/widgets/
// ข้อมูลเก็บที่ ~/.todo-widget.json

import { run, css } from "uebersicht";

const FILE = "$HOME/.todo-widget.json";

export const command = `cat "${FILE}" 2>/dev/null || echo "[]"`;
export const refreshFrequency = false;

export const initialState = { todos: [], loaded: false };

// เขียนไฟล์แบบ base64 กันปัญหาภาษาไทย/เครื่องหมายคำพูด
const save = (todos) => {
  const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(todos))));
  run(`echo '${b64}' | base64 -D > "${FILE}"`);
};

export const updateState = (event, prev) => {
  let todos;
  switch (event.type) {
    case "UB/COMMAND_RAN":
      if (prev.loaded) return prev;
      try {
        return { todos: JSON.parse(event.output || "[]"), loaded: true };
      } catch {
        return { todos: [], loaded: true };
      }
    case "ADD":
      todos = [...prev.todos, { id: Date.now(), text: event.text, done: false }];
      break;
    case "TOGGLE":
      todos = prev.todos.map((t) => (t.id === event.id ? { ...t, done: !t.done } : t));
      break;
    case "DELETE":
      todos = prev.todos.filter((t) => t.id !== event.id);
      break;
    default:
      return prev;
  }
  save(todos);
  return { ...prev, todos };
};

// Light Rose and Cream palette: box fbcdd5 -> f9afc8, text/accent 5a1033 / d6447f.
export const className = css`
  top: 120px;
  right: 40px;
  width: 280px;
  font-family: -apple-system, "SF Pro Text", "Sukhumvit Set", "Thonburi", sans-serif;
  color: #5a1033;
`;

const box = css`
  position: relative;
  background: linear-gradient(145deg, rgba(251, 205, 213, 0.92), rgba(249, 175, 200, 0.92));
  box-shadow: 0 8px 28px rgba(214, 68, 127, 0.25);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  border: 1px solid rgba(214, 68, 127, 0.35);
  border-radius: 14px;
  padding: 14px 14px 10px;
`;

const header = css`
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  font-size: 15px;
  font-weight: 600;
  margin-bottom: 10px;
  span { font-size: 12px; font-weight: 400; opacity: 0.75; }
`;

const input = css`
  width: 100%;
  box-sizing: border-box;
  background: rgba(90, 16, 51, 0.08);
  border: 1px solid transparent;
  border-radius: 8px;
  padding: 8px 10px;
  color: inherit;
  font: inherit;
  font-size: 13px;
  outline: none;
  &:focus { border-color: #d6447f; }
  &::placeholder { color: rgba(90, 16, 51, 0.55); }
`;

const list = css`
  list-style: none;
  margin: 8px 0 0;
  padding: 0;
  max-height: 420px;
  overflow-y: auto;
`;

const item = css`
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 7px 2px;
  font-size: 13px;
  border-top: 1px solid rgba(90, 16, 51, 0.1);
  &:first-child { border-top: none; }
  .del { margin-left: auto; opacity: 0; cursor: pointer; padding: 0 4px; }
  &:hover .del { opacity: 0.75; }
  .del:hover { opacity: 1; }
`;

const check = css`
  flex: none;
  width: 16px;
  height: 16px;
  box-sizing: border-box;
  border-radius: 50%;
  border: 1.5px solid rgba(90, 16, 51, 0.6);
  cursor: pointer;
  &:hover { border-color: #5a1033; }
`;

// Checked: the flower from todo-assets/flower-sprite.png
// (37 frames of 48px, shown at 20px). It blooms once, then stays still.
const FLOWER = 20, FRAMES = 37;
const flower = css`
  flex: none;
  width: ${FLOWER}px;
  height: ${FLOWER}px;
  margin: -2px;
  cursor: pointer;
  background: url("todo.widget/todo-assets/flower-sprite.png") 0 0 / ${FLOWER * FRAMES}px ${FLOWER}px no-repeat;
  filter: drop-shadow(0 0 3px rgba(90, 16, 51, 0.25));
  animation: todoBloom 2.6s steps(${FRAMES - 1}) forwards, todoPop 0.35s ease-out;
`;

const keyframes = `
  @keyframes todoBloom { to { background-position: -${FLOWER * (FRAMES - 1)}px 0; } }
  @keyframes todoPop { 0% { transform: scale(0.2) rotate(-40deg); } 70% { transform: scale(1.25); } 100% { transform: scale(1); } }
`;

const text = (done) => css`
  flex: 1;
  word-break: break-word;
  cursor: pointer;
  opacity: ${done ? 0.45 : 1};
  text-decoration: ${done ? "line-through" : "none"};
`;

export const render = ({ todos }, dispatch) => {
  const left = todos.filter((t) => !t.done).length;
  return (
    <div className={box}>
      <style>{keyframes}</style>
      <div className={header}>
        To-do <span>เหลือ {left}</span>
      </div>
      <input
        className={input}
        placeholder="เพิ่มงาน แล้วกด Enter"
        onKeyDown={(e) => {
          const v = e.target.value.trim();
          if (e.key === "Enter" && v) {
            dispatch({ type: "ADD", text: v });
            e.target.value = "";
          }
        }}
      />
      <ul className={list}>
        {todos.map((t) => (
          <li key={t.id} className={item}>
            <span className={t.done ? flower : check} onClick={() => dispatch({ type: "TOGGLE", id: t.id })} />
            <span className={text(t.done)} onClick={() => dispatch({ type: "TOGGLE", id: t.id })}>
              {t.text}
            </span>
            <span className="del" onClick={() => dispatch({ type: "DELETE", id: t.id })}>✕</span>
          </li>
        ))}
      </ul>
    </div>
  );
};
