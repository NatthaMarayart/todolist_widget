To-do widget for Übersicht — macOS

1. ติดตั้ง Übersicht (ฟรี): https://tracesof.net/uebersicht/
   ถ้าเปิดไม่ได้ ให้คลิกขวาที่แอป > Open
2. คลิกไอคอน Übersicht บนแถบเมนูด้านบน > "Open Widgets Folder"
3. ลากโฟลเดอร์ "todo.widget" ทั้งโฟลเดอร์ไปวางในโฟลเดอร์นั้น
4. Widget จะขึ้นที่มุมขวาบนของหน้าจอ

ใช้งาน: พิมพ์งานแล้วกด Enter · คลิกเพื่อติ๊กเสร็จ (มีดอกไม้บาน 🌼) · ชี้แล้วกด ✕ เพื่อลบ

---
1. Install Übersicht (free): https://tracesof.net/uebersicht/
   If macOS blocks it, right-click the app > Open.
2. Click the Übersicht icon in the menu bar > "Open Widgets Folder".
3. Drag the whole "todo.widget" folder into it.
4. The widget appears in the top-right of the screen.
